# Last Pick — iOS App (App Store) build guide

This folder turns the Last Pick web app into a real iOS app you can submit to the App Store, using **Capacitor** (it wraps the app in a native shell). The app content is bundled locally; live data (movies via the Netlify proxy, accounts via Supabase) is fetched over the network.

You do the final build on a **Mac** — Apple requires Xcode, which is Mac-only. Everything else is prepared for you.

---

## What you need (one time)

1. **A Mac** with **Xcode** installed (free from the Mac App Store).
2. **Node.js** (https://nodejs.org — LTS).
3. **CocoaPods**: in Terminal run `sudo gem install cocoapods` (or `brew install cocoapods`).
4. **An Apple Developer account** — $99/year, enroll at https://developer.apple.com/programs/enroll/. Required to sign and submit.

---

## Build it (run these in Terminal, inside this folder)

```bash
cd LastPick-iOS
npm install
npx cap add ios                 # creates the native iOS project
npx capacitor-assets generate --ios   # generates all app icons + splash from resources/
npx cap sync ios                # copies web app + installs native pods
npx cap open ios                # opens the project in Xcode
```

If `npx capacitor-assets` isn't found, run `npm i -D @capacitor/assets` first.

---

## In Xcode (signing + upload)

1. In the left sidebar click the blue **App** project → select the **App** target.
2. **Signing & Capabilities** tab:
   - Check **Automatically manage signing**.
   - **Team**: pick your Apple Developer account.
   - **Bundle Identifier**: `com.lastpick.app` — change it if you want (must be globally unique; reverse-domain style). Whatever you choose, it must match the app you create in App Store Connect.
3. **General** tab: set **Display Name** = `Last Pick`, **Version** = `1.0`, **Build** = `1`.
4. Top bar: set the device target to **Any iOS Device (arm64)**.
5. Menu **Product → Archive**. When it finishes, the Organizer opens.
6. Click **Distribute App → App Store Connect → Upload**. Follow the prompts.

---

## In App Store Connect (https://appstoreconnect.apple.com)

1. **My Apps → + → New App.** Platform iOS, Name **Last Pick**, your primary language, the **Bundle ID** you used, and an SKU (any unique string, e.g. `lastpick-001`).
2. Fill in the listing (copy/paste from the section below).
3. **Screenshots** — required. Easiest way: run the app in the iPhone **Simulator** (in Xcode: pick an iPhone 15 Pro Max simulator → Run), then Cmd+S to save screenshots. Apple needs at least the **6.7" iPhone** size (1290 × 2796). Grab 3–5 good screens (the spin/pick screen, a movie sheet, For You, Kids Mode).
4. **Age rating**: answer the questionnaire — Last Pick is fine as **4+** (it shows movie info; no mature content in the app itself). If you show R-rated movie posters/overviews you may prefer **12+**.
5. **App Privacy**: see the privacy section below.
6. Attach the build you uploaded, then **Add for Review → Submit**.

First review usually takes 1–3 days.

---

## Ready-to-paste App Store listing

**Name:** Last Pick

**Subtitle (30 chars max):** Stop scrolling. Start watching.

**Promotional text:** Can't decide what to watch? Hit spin — Last Pick lands on the perfect movie for your mood, your taste, and tonight.

**Description:**
```
Stop scrolling. Start watching.

Last Pick ends the nightly "what should we watch?" standoff. Tap spin and we land on one movie — chosen for your taste, your mood, and how much brain power you've got left tonight.

• One-tap picks. No endless browsing. We commit to a movie so you don't have to.
• Tuned to you. The more you react, the sharper your recommendations get.
• Set the vibe. Scary, funny, mind-bending, background noise, date night — pick a mood and go.
• Shared universes. See every film in a world (Marvel, Alien/Predator, and hundreds more), sorted by timeline or by character.
• Kids Mode. A safe, simple picker just for the little ones.
• Watchlist, watch history, and a taste profile that grows with you.

Movie data provided by TMDB. This product uses the TMDB API but is not endorsed or certified by TMDB.
```

**Keywords (100 chars):** `movie,what to watch,picker,film,cinema,recommend,random,tonight,decide,watchlist,mood,tv`

**Support URL:** your site or a simple contact page (e.g. a "Contact" page, or `https://lastpick-app.netlify.app`).
**Marketing URL (optional):** `https://lastpick-app.netlify.app`

---

## App Privacy answers (App Store Connect → App Privacy)

Last Pick uses **Supabase** for optional accounts and to sync your taste data. Declare:
- **Contact Info → Email Address**: collected, linked to identity (used for login). *Not* used for tracking.
- **Identifiers → User ID**: collected (account id), linked to identity.
- **Usage Data → Product Interaction**: collected (which movies you rate/pick, to personalize). Linked to identity, not used for tracking.
- **Data used to track you:** None.

**Privacy Policy URL is REQUIRED.** You don't have one yet — ask me and I'll generate a simple privacy policy page and host it on your site (e.g. `https://lastpick-app.netlify.app/privacy`). Apple will reject without this.

---

## Updating the app later

When you change the web app (`FinalPick.html`):
1. Copy the new file over `www/index.html` in this folder.
2. `npx cap copy ios`
3. In Xcode bump **Build** (e.g. 1 → 2), Archive, and upload again.

(Alternative for instant updates without re-submitting: point Capacitor at the live site by adding `"url": "https://lastpick-app.netlify.app"` inside `server` in `capacitor.config.json`. Trade-off: it becomes a thin wrapper of the website, which Apple *can* scrutinize under guideline 4.2. The bundled approach above is the safer default.)

---

## Notes
- The app bundles the current web app and calls the **live** Netlify TMDb proxy + Supabase, so movies and accounts work from the app. (The proxy now sends CORS headers so the app is allowed to call it.)
- Social logins (Google/Discord/Facebook) are **hidden in the app** on purpose — they'd trigger Apple's "Sign in with Apple" requirement and aren't set up. Email/username sign-in works.
- `resources/icon.png` (1024, no transparency) is your App Store icon; `resources/splash.png` is the launch screen. Re-run `npx capacitor-assets generate --ios` if you change them.
